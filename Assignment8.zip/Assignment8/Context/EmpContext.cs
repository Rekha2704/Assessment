﻿using Assignment8.Models;
using Microsoft.EntityFrameworkCore;
namespace Assignment8.Context
{
        public class EmpDbContext : DbContext
        {
            public EmpDbContext() { }
            public EmpDbContext(DbContextOptions<EmpDbContext> dbContextOptions) 
                : base(dbContextOptions)
            {   
            }
            public DbSet<Employee> Employees { get; set; }
            public DbSet<Department> Departments { get; set; }
        }
}
