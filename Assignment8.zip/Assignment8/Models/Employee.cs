﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Assignment8.Models
{
    public class Employee
    {
        [Required]
        [Key]
        public int EmpId { get; set; }
        [Required]
        [RegularExpression(@"^[a-zA-Z\s]+$",ErrorMessage = "Name should in alphabets")]
        public string EmpName { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [Range(typeof(DateTime), "01-01-2002", "01-01-2005", ErrorMessage = "Date must be between 1/1/1900 and 1/1/2022")]
        public DateTime EmpDOB { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [CustomValidation(typeof(Employee), nameof(ValidateDateOfJoining))]
        public DateTime DateOfJoining { get; set; }

        [Range(12000, 60000, ErrorMessage = "Salary should be between 12000 and 60000.")]
        public int? Salary { get; set; }
        [Required]
        [ForeignKey("Department")]
        public int DeptId { get; set; }
        public Department Dept { get; set; }

        public static ValidationResult ValidateDateOfJoining(DateTime dateOfJoining, ValidationContext context)
        {
            if (dateOfJoining > DateTime.Now)
            {
                return new ValidationResult("Date of Joining should not be greater than current date.");
            }
            return ValidationResult.Success;
        }
    }
}
