﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Assignment8.Models
{
    public class Department
    {
        [Key]
        public int DeptId { get; set; }
        [Required]
        [StringLength(1000)]
        public string DeptName { get; set; }
        [ForeignKey("Employee")]
        public int? Managerid { get; set; }
        public Employee Manager { get; set; }
    }
}
