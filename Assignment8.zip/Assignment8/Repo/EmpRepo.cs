﻿namespace Assignment8.Repo
{
    public class EmpRepo
    {

    }
}
